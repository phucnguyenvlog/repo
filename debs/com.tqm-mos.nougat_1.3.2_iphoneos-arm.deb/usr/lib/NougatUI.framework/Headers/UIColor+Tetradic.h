#import <UIKit/UIKit.h>

@interface UIColor (Tetradic)
@property (copy, readonly, nonatomic) NSArray<UIColor *> *tetradicColors;
@property (strong, readonly, nonatomic) UIColor *accentColor;

- (BOOL)isSimilarToColor:(UIColor *)color;

@end